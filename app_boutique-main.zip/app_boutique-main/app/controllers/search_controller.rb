class SearchController < ApplicationController
  def index
    @q = Post.ransack(params[:q])
    @posts= @q.result(distinct: true)
 
  end
end
